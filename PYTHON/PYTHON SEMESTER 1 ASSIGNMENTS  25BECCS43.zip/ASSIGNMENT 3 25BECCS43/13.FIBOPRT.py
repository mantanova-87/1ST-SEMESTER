#Write a program to print fibonacci series upto number input from user.
N=int(input("ENTER THE NUMBER OF TERMS YOU WANT TO PRINT: "))
A=0
B=1
print("THE REQUIRED FIBONACCI SERIES IS AS FOLLOWS: ")
print(A)
print(B)
for i in range(0,N-2):
    C=A+B
    A=B
    B=C
    print(C)

