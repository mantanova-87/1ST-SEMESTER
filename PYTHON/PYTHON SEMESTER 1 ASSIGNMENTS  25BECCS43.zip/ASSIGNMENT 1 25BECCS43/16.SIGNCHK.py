#Given a number, check whether it is positive, negative, or zero.
A=int(input("ENTER A NUMBER: "))
if A>0:
    print("THE GIVEN NUMBER",A,"IS POSITIVE.")
elif A==0:
    print("THE GIVEN NUMBER IS 0.")
else:
    print("THE GIVEN NUMBER IS NEGATIVE.")
