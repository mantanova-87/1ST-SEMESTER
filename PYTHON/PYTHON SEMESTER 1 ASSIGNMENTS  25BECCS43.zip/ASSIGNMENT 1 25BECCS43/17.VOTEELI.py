'''Age Check (Voting Eligibility)-Input age and check eligibility. If eligible print the message “You are eligible to vote”, otherwise print “Not Eligible”.'''
AG=int(input("ENTER YOUR AGE: "))
if AG>=18:
    print("YOU ARE ELIGIBLE TO VOTE")
else:
    print("YOU ARE NOT ELIGIBLE TO VOTE")
