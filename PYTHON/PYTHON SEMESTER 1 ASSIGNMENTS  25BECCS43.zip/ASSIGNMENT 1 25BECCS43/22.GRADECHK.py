'''Given a student's marks (out of 100), print the grade:
90-100: "A+" 
80-89: "A" 
70-79: "B" 
60-69: "C" 
50-59: "D" 
Below 50: "Fail"'''
MKS=int(input("ENTER YOUR MARKS: "))
if MKS>=90:
    print("YOUR GRADE IS (A+).")
elif MKS>=80 and MKS<=89:
    print("YOUR GRADE IS (A).")
elif MKS>=70 and MKS<=79:
    print("YOUR GRADE IS (B).")
elif MKS>=60 and MKS<=69:
    print("YOUR GRADE IS (C).")
elif MKS>=50 and MKS<=59:
    print("YOUR GRADE IS (D).")
elif MKS<50:
    print("YOU HAVE FAILED.")
elif MKS>100 and MKS<0:
    print("INVALID INPUT.")
    
