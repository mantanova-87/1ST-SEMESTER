#Write a program to find sum of series: 2+22+222+2222+……..+n
N=int(input("ENTER THE NUMBER OF TERMS WHOSE SUM TO CALCULATE IN THIS SERIES: "))
S=0
for i in range(1,N+1):
    B="2"
    S+=(int(B*i))
print("THE SUM OF FIRST",N,"TERMS OF THE SERIES IS",S)
    
