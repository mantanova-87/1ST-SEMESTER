# Calculate Simple Interest.
P=int(input("ENTER THE PRINCIPAL AMOUNT: "))
R=int(input("ENTER THE RATE OF INTEREST: "))
T=int(input("ENTER THE DURATION OF INTEREST IN YEARS: "))
SI=(P*R*T)/100
print("THE SIMPLE INTEREST IS",SI)
