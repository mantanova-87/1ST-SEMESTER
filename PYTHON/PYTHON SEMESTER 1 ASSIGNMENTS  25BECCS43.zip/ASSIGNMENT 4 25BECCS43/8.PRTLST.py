#Declare a function named print_list. It takes a list as a parameter and it prints  out each element of the list.
def print_list(L):
    for i in L:
        print(i)
A=int(input("ENTER THE NUMBER OF ELEMENTS YOU WANT IN YOUR LIST: "))
M=[]
for j in range(0,A):
    B=input("ENTER THE  ELEMENTS YOU WANT IN YOUR LIST: ")
    M.append(B)
print_list(M)    

    
    
