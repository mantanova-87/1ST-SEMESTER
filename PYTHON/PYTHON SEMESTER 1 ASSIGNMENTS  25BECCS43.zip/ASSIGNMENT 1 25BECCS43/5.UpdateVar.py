#Write a program to create a variable num = 10, print it, then change its value to 20 and print again.
num=10
print("Value of num is ",num)
num=20
print("Updated Value of num is ",num)
