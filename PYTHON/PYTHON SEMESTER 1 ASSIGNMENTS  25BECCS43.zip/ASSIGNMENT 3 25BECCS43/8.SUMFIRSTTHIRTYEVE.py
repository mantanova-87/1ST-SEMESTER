# Write a program to print sum of 1st 30 even numbers.
SUM=0
for i in range(0,61):
    if i%2==0:
        SUM+=i
print("SUM OF FIRST 30 EVEN NUMBERS IS: ",SUM)
