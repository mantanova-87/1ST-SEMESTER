'''Two cricket teams A and B have played a match. The result is decided based on the 
following rules: 
 The team with higher runs is declared the winner. 
 If the runs are the same, the team with fewer wickets lost is the winner. 
 If both runs and wickets lost are also the same, the match is declared a Draw.'''
AR,AW=int(input("ENTER THE RUNS SCORED BY TEAM A: ")),int(input("ENTER THE WICKETS LOST BY TEAM A: "))
BR,BW=int(input("ENTER THE RUNS SCORED BY TEAM B: ")),int(input("ENTER THE WICKETS LOST BY TEAM B: "))
if AR!=BR:
    if AR>BR:
        print("TEAM A WON THE MATCH!!!")
    else:
        print("TEAM B WON THE MATCH!!!")
elif AR==BR and AW!=BW:
    if AW>BW:
        print("TEAM A WON THE MATCH!!!")
    else:
        print("TEAM B WON THE MATCH!!!")
elif AR==BR and AW==BW:
    print("THE MATCH WAS A DRAW!!!")



