# Store marks of 5 subjects: Hindi, Math, Science, English, IT and calculate total.
H=float(input("ENTER THE MARKS IN HINDI: "))
M=float(input("ENTER THE MARKS IN MATHS: "))
S=float(input("ENTER THE MARKS IN SCIENCE: "))
E=float(input("ENTER THE MARKS IN ENGLISH: "))
I=float(input("ENTER THE MARKS IN IT: "))
CALC=H+M+S+E+T
print("THE TOTAL MARKS OF 5 SUBJECTS IS ",CALC)
