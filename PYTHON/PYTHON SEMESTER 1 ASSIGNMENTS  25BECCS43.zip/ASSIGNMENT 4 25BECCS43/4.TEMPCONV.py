#Temperature in °C can be converted to °F using this formula: °F = (°C x 9/5)  + 32. Write a function which converts °C to °F, convert_celsius_to-fahrenheit.
def convert_celcius_to_farenheit():
    C=int(input("ENTER THE TEMPERATURE IN CELCIUS: "))
    F=(C*(9/5))+32
    print("THE TEMPERATURE GIVEN IN CELCIUS CONVERTED TO FARENHEIT IS: ",F)
    
convert_celcius_to_farenheit()
    
    
