
#Write a function called calculate_slope which return the slope of a linear  equation
def calculate_slope():
    print("THE GENERAL EQUATION OF A LINEAR EQUATION IS y=mx+c")
    E=input("ENTER THE EQUATION IN GENERAL FORM: ")
    if E[0]=="y":
        I=E.find("x")
        if I==3:
            if E[2]=="-":
                print("SLOPE OF THE GIVEN LINEAR EQUATION IS -1")
            else:
                print("SLOPE OF THE GIVEN LINEAR EQUATION IS: ",E[2])
        elif I ==2:
            print("SLOPE OF THE GIVEN LINEAR EQUATION IS 1. ")
        elif I ==(-1):
            print("SLOPE OF THE GIVEN LINEAR EQUATION IS 0. ")
        elif I ==4:
            print("SLOPE OF THE GIVEN LINEAR EQUATION IS: ",E[2:4])
    else:
        print("PLEASE ENTER EQUATION IN GENERAL FORM AS MENTIONED ABOVE!!!")
calculate_slope()
            

        
        

        

        
    

          
