#Write a function called check-season, it takes a month parameter and returns  the season: Autumn, Winter, Spring or Summer.
def check_season():
    M=input("ENTER THE SEASON: ")
    if M.upper() in ("FEBRUARY","MARCH","APRIL"):
        print("ITS SPRING SEASON.")
    elif M.upper() in ("MAY","JUNE","JULY"):
        print("ITS SUMMER SEASON")
    elif M.upper() in ("AUGUST","SEPTEMBER","OCTOBER"):
        print("ITS AUTUMN SEASON")
    elif M.upper() in ("NOVEMBER","DECEMBER","JANUARY"):
        print("ITS WINTER SEASON")
check_season()
    
        
    
