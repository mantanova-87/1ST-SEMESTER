#Write a program to create two variables a = 10, b = 20 and display them.
a=10
b=20
print("FIRST VARIABLE a=",a)
print("FIRST VARIABLE b=",b)
