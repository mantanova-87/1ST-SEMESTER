#PROGRAM TO CHECK SCHOLARSHIP ELIGIBILITY ON THE BASIS OF GIVEN CONDITION.
P=int(input("ENTER YOUR PERCENTAGE: "))
if P>=90:
    print("FULL SCHOLARSHIP!!!.")
elif P<90 and P>=75:
    I=int(input("ENTER YOUR FAMILY INCOME: "))
    if I<200000:
          print("HALF SCHOLARSHIP!!!")
    else:
        print("NO SCHOLARSHIP!!!")
else:
    print("NO SCHOLARSHIP!!!")
    
