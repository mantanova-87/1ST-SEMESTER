#Write a program to calculate the total bill for 3 items.
A=int(input("Enter the price of first item: "))
B=int(input("Enter the price of second item: "))
C=int(input("Enter the price of third item: "))
print("THE TOTAL BILL OF THE GIVEN ITEMS IS : ",A+B+C)
