#Create variables to store your name, age, and city. Print them.
NM=(input("Enter your  name: "))
RN=int(input("Enter your age: "))
PT=(input("Enter your city: "))
print("YOUR NAME IS ",NM)
print("YOUR AGE IS ",RN)
print("YOUR CITY IS ",PT)
