'''Given three sides of a triangle, determine its type: 
a. If all three sides are equal, print "Equilateral" 
b. If two sides are equal, print "Isosceles" 
c. If all three sides are different, print "Scalene" 
d. If it does not form a valid triangle, print "Not a Triangle"'''
A=int(input("ENTER THE LENGTH OF FIRST SIDE: "))
B=int(input("ENTER THE LENGTH OF SECOND SIDE: "))
C=int(input("ENTER THE LENGTH OF THIRD SIDE: "))
if A+B>C and A+C>B and B+C>A:
    if A==B==C:
        print("THE GIVEN SIDES",A,",",B,"AND",C,"FORM AN EQUILATERAL TRIANGLE.")
    elif A==B!=C or B==C!=A or A==C!=B:
        print("THE GIVEN SIDES",A,",",B,"AND",C,"FORM AN ISOSCELES TRIANGLE.")
    else:
        print("THE GIVEN SIDES",A,",",B,"AND",C,"FORM A SCALENE TRIANGLE.")
else:
    print("THE GIVEN SIDES",A,",",B,"AND",C,"DOES NOT FORM A TRIANGLE.")
        

