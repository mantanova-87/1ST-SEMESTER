# Take your name as input and print a greeting.
N=input("ENTER YOUR NAME: ")
print("HELLO ",N,"!" )
