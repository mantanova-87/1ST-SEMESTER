#Write a program to print a multiplication table for any number  given by the user.
A=int(input("ENTER THE NUMBER WHOSE TABLE YOU WISH TO PRINT: "))
for i in range(1,11):
    print(A,"*",i,"=",A*i)
