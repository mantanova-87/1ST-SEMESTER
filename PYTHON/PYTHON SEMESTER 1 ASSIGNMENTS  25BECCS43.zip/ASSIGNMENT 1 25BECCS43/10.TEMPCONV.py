# Write a program to convert Celsius temperature into Fahrenheit.
T=float(input("ENTER THE TEMPERATURE IN DEGREE CELCIUS :"))
F=(T*(9/5)+32)
print("THE TEMPERATURE GIVEN IN CELCIUS IS EQUIVALENT TO ",F," DEGREE FARENHEIT.")

