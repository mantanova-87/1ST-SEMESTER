'''Write a program to create a simple Personal Information Card 
using variables in Python. The program should store a person’s details such as Name, 
Age, Gender, College, Course, Roll Number, Contact Number, and Address in 
separate variables. Finally, print all the information in a properly formatted way so that it 
looks like an identity card.'''
NM=input("ENTER YOUR NAME: ")
AG=int(input("ENTER YOUR AGE: "))
GN=input("ENTER YOUR GENDER: ")
CG=input("ENTER THE NAME OF YOUR COLLEGE: ")
RN=input("ENTER YOUR ROLL NUMBER: ")
CS=(input("ENTER YOUR COURSE: "))
MN=int(input("ENTER YOUR CONTACT NUMBER: "))
ADD=input("ENTER YOUR ADDRESS: ")
print("---------------------------------")
print("          IDENTITY CARD          ")
print("---------------------------------")
print("NAME          :",NM)
print("AGE           :",AG)
print("GENDER        :",GN)
print("COLLEGE       :",CG)
print("COURSE        :",CS)
print("ROLL NUMBER   :",RN)
print("CONTACT NUMBER:",MN)
print("ADDRESS       :",ADD)
