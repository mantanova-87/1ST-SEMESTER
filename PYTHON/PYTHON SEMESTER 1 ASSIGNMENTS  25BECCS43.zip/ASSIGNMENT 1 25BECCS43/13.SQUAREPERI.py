#Write a program to calculate the perimeter of a square.
A=int(input("ENTER THE LENGTH OF SIDE SQUARE: "))
B=input("ENTER THE UNIT OF LENGTH OF SIDE: ")
print("THE AREA OF THE SQUARE IS ",A*4," SQUARE ",B)
