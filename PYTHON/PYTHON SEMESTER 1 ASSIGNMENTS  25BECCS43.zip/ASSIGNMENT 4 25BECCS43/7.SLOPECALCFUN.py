#Quadratic equation is calculated as follows: ax² + bx + c = 0. Write a function  which calculates solution set of a quadratic equation, solve_quadratic_eqn.
import math as M
def quad_roots():
    print("GENERAL FORM OF QUADRATIC EQUATION IS GIVEN AS ax**2+bx+c=0.")
    A=int(input("PLEASE ENTER THE COEFFICIENT OF  x**2: "))
    B=int(input("PLEASE ENTER THE COEFFICIENT OF  x."))
    C=int(input("PLEASE ENTER THE CONSTANT TERM: "))
    D=B**2-4*A*C
    if D<0:
        print("NO REAL ROOTS.")
    else:
        R1=(-B+M.sqrt(D))/2*A
        R2=(-B-M.sqrt(D))/2*A
        print("THE ROOTS OF THE GIVEN EQUATION ARE ",R1,"AND",R2)
quad_roots()
    
    
    
    
    
