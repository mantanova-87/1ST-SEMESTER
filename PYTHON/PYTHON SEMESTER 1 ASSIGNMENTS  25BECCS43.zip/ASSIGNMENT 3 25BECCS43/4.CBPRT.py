#4. Write a program to print square of numbers from 1-5.
for i in range(1,6):
    print("CUBE OF",i,"IS",i**3)
