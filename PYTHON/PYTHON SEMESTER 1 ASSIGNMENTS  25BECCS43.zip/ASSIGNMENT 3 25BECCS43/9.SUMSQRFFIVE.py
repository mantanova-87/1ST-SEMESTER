#Write a program to print sum of squares of 1st 5 natural  numbers.
S=0
for i in range(1,6):
    S+=(i**2)
print("SUM OF SQUARES OF FIRST FIVE NATURAL NUMBERS IS: ",S)
