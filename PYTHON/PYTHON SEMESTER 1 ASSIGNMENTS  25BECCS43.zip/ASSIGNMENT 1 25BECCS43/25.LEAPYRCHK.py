#TO CHECK WHETHER THE YEAR ENTERED BY A USER IA LEAP YEAR OR NOT.
Y=int(input("ENTER THE YEAR FOR BEING A LEAP YEAR: "))
if Y%400==0:
    print("THE YEAR",Y,"IS A LEAP YEAR.")
elif Y%4==0:
    if Y%100!=0:
         print("THE YEAR",Y," IS A LEAP YEAR.")
    else:
         print("THE YEAR",Y,"IS NOT A LEAP YEAR.")
else:
    print("THE YEAR",Y,"IS NOT A LEAP YEAR.")
