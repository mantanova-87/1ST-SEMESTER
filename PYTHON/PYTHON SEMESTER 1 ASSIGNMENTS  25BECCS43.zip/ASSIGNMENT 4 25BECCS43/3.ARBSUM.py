#Write a function called add_all_nums which takes arbitrary number of  arguments and sums all the arguments.
def add_all_nums(L):
    S=0
    for i in L:
        S+=i
    return S
A=int(input("ENTER THE NUMBER OF ARGUMENTS TO PASS : "))
M=[]
for j in range(0,A):
    B=int(input("ENTER THE NUMBER  : "))
    M.append(B)
T=add_all_nums(M)
print("SUM IS",T)
    
    
    
