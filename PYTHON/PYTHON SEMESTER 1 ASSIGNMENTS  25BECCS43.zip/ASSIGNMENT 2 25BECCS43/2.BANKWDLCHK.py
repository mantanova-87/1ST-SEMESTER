'''#Rules for a bank transaction: 
 Withdrawals must be in multiples of 5. 
 Bank charges ₹0.50 per successful transaction. 
 If balance is insufficient, transaction fails.'''
import random as R
B=R.randint(499,75001)
print("DEAR CUSTOMER YOUR BALANCE IS: ",B,"RUPEES")
W=int(input("PLEASE ENTER THE AMOUNT YOU WISH TO WITHDRAW ENSURING ITS IN MULTIPLES OF 5: "))
if W%5==0:
    if (W+0.5)<=B:
        print("TRANSACTION SUCCESSFUL!!!")
        print("COLLECT YOUR CASH AND COUNT BEFORE LEAVING THE ATM!!!")
        print("BALANCE: ",B-W-0.5)
    else:
        print("TRANSACTION FAILED!!!INSUFFICIENT BALANCE!!!")
else:
    print("TRANSACTION FAILED!!!REQUESTED AMOUNT INVALID AS PER AVAILABLE DENOMINATIONS")
    
    

