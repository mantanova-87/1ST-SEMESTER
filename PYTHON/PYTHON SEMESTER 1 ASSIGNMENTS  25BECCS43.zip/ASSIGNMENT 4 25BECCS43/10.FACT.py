#Declare a function that takes a whole number as a parameter and returns a  factorial of the number
def fact():
    A=int(input("ENTER THE NUMBER TO FIND ITS FACTORIAL: "))
    F=1
    for i in range(A,0,-1):
        F*=i
    print("FACTORIAL OF THE GIVEN NUMBER",A," IS: ",F)
fact()
