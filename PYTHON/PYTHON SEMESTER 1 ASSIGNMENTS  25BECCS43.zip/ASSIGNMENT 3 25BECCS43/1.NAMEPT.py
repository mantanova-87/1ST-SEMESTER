#1. Write a program to print your name 20 times.
A=input("ENTER YOUR NAME: ")
for i in range(1,21):
    print(i," :  ",A)
