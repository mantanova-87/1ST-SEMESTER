#Write a program to assign values to three variables in a single line and print them.
NAME,AGE,CITY=input("Enter your name: "),int(input("Enter your age: ")),input("Enter your city: ")
print("YOUR NAME IS ",NAME," YOUR AGE IS ",AGE," YOUR CITY IS ",CITY)

