#Write a program to display a factorial of a number input from user.
A=int(input("ENTER THE NUMBER TO FIND ITS FACTORIAL: "))
F=1
for i in range(A,0,-1):
    F*=i
print("FACTORIAL OF THE GIVEN NUMBER",A," IS: ",F)
