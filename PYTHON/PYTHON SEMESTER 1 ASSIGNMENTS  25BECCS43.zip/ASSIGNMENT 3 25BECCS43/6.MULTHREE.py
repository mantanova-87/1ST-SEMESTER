#Write a program to print only multiple of 3 upto 30.
for i in range(1,31):
    if i%3==0:
        print(i)
