#Write a Python program to check if a given number is even or odd.
AG=int(input("ENTER THE NUMBER: "))
if AG%2==0:
    print("THE GIVEN NUMBER IS EVEN.")
else:
        print("THE GIVEN NUMBER IS ODD.")
