import math as M
def AREAC():
    R=int(input("ENTER THE RADIUS OF CIRCLE IN METRES: "))
    A=(M.pi)*R**2
    print("AREA OF THE CIRCLE WITH RADIUS ",R," METRES IS",A,"SQUARE METRES")
AREAC()
