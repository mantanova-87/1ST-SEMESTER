# Check if a number is divisible by both 3 and 5.
A=int(input("ENTER THE NUMBER TO CHECK FOR DIVISIBILTY BY BOTH 3 AND 5: "))
if A%15==0:
    print("THE GIVEN NUMBER IS DIVISIBLE BY BOTH 3 AND 5.")
else:
    print("THE GIVEN NUMBER ISN'T DIVISIBLE BY BOTH 3 AND 5.")
