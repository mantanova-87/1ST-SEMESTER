#Write a program to display product of cubes of 1-5.
S=1
for i in range(1,6):
    S*=(i**2)
print("PRODUCT OF CUBES OF FIRST FIVE NATURAL NUMBERS IS: ",S)

