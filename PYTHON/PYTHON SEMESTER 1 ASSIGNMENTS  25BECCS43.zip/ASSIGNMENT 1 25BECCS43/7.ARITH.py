
# Take two numbers and print:  Sum Difference Product Quotient Remainder
A=int(input("ENTER THE FIRST NUMBER: "))
B=int(input("ENTER THE SECOND NUMBER: "))
print("THE SUM OF ",A," AND ",B," IS ",A+B)
print("THE DIFFERENCE OF ",A," AND ",B," IS ",A-B)
print("THE PRODUCT OF ",A," AND ",B," IS ",A*B)
print("THE QUOTIENT WHEN ",A," IS DIVIDED BY ",B," IS ",A//B)
print("THE REMAINDER WHEN ",A," IS DIVIDED BY ",B," IS ",A%B)
