#Find the square and cube of a number.
A=int(input("ENTER THE NUMBER: "))
print("THE SQUARE OF THE GIVEN NUMBER ",A,"IS ",A**2,"AND ITS CUBE IS ", A**3)
