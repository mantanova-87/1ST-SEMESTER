#Write a program to store roll number (integer), name (string), and percentage (float) in variables, and print them.
RN=int(input("Enter your roll number: "))
NM=(input("Enter your  name: "))
PT=float(input("Enter your percentage: "))
print("YOUR ROLL NUMBER IS ",RN)
print("YOUR NAME IS ",NM)
print("YOUR PERCENTAGE IS ",PT," %")
