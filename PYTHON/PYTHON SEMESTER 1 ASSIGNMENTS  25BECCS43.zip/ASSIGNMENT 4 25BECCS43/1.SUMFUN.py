#Declare a function add_two_numbers. It takes two parameters and it returns a  sum.
def SUM(X,Y):
    S=X+Y
    return S
A=int(input("ENTER THE FIRST NUMBER: "))
B=int(input("ENTER THE SECOND NUMBER: "))
P=SUM(A,B)
print("SUM OF THE ENTERED NUMBERS IS: ",P)
