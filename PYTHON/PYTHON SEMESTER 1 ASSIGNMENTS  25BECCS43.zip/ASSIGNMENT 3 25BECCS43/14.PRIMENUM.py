#Write a program to check the number entered is prime or not.
A=int(input("ENTER THE NUMBER TO CHECK FOR BEING PRIME: "))
if A<=1 or A==4:
    print(A,"IS NOT A PRIME NUMBER.")
elif A==2:
    print(A,"IS THE SMALLEST AS WELL AS THE ONLY PRIME NUMBER.")
elif A==3 or A==5:
    print(A,"IS A PRIME NUMBER.")
else:
    for i in range(2,A//2):
        if A%i==0:
            print(A,"IS NOT A PRIME NUMBER.")
            break
        else:
            print(A,"IS A PRIME NUMBER.")
        
