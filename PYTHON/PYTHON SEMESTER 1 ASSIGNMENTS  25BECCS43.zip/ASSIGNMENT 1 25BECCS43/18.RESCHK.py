#Take as input marks of a subject. Print "Pass" if marks ≥ 40,otherwise "Fail".
A=int(input("ENTER YOUR MARKS: "))
if A>=40:
    print("PASS")
else:
    print("FAIL")
