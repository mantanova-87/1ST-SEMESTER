'''The same customer applies for a loan. Eligibility rules are: 
 Salary > ₹30,000 → Eligible for loan. 
 If salary > ₹50,000 → Maximum loan up to ₹10,00,000. 
 If salary between ₹30,000–₹50,000 → Maximum loan up to ₹5,00,000. 
 If credit score < 600 → Loan denied. 
 If credit score > 750 → Add bonus eligibility of ₹2,00,000.'''
S=int(input("ENTER YOUR SALARY: "))
C=int(input("ENTER YOUR CREDIT SCORE: "))
if C<600:
    print("LOAN REQUEST REJECTED!!!")
elif C>600 and C<=750:
    if S>30000:
        print("ELIGIBLE FOR LOAN!!!")
    elif S>30000 and S<=50000:
        print("MAXIMUM LOAN UPTO RUPEES 500000.")
    elif S>50000:
        print("MAXIMUM LOAN UPTO RUPEES 1000000.")
elif C>750:
    if S>30000:
        print("ELIGIBLE FOR LOAN WITH BONUS ELIGIBILITY OF 200000!!!")
    elif S>30000 and S<=50000:
        print("MAXIMUM LOAN UPTO RUPEES 700000.")
    elif S>50000:
        print("MAXIMUM LOAN UPTO RUPEES 1200000.")





        
    
