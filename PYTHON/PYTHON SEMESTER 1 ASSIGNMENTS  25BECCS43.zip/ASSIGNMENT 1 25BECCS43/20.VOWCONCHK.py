#Given a character, check if it is a vowel or consonant.
C=input("ENTER A CHARACTER TO CHECK FOR BEING A VOWEL OR CONSONANT: ")
if C.upper() in ("A","E","I","O","U"):
        print("ENTERED CHARACTER IS A VOWEL.")
else:
    print("THE ENTERED CHARACTER IS A CONSONANT.")
