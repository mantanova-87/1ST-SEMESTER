#. Write a program to print a number 20 times.
A=int(input("ENTER YOUR NAME: "))
for i in range(1,21):
    print(i," :  ",A)
