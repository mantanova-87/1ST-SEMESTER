# Write a program to print a sentence using three variables.
A=input("ENTER FIRST PART OF SENTENCE: ")
B=input("ENTER SECOND PART OF SENTENCE: ")
C=input("ENTER THIRD PART OF SENTENCE: ")
print(A,B,C)

